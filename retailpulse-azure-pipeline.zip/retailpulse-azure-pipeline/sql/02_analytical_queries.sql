/* =========================================================================
   Analytical queries for the Power BI dashboard / interview talking points
   ========================================================================= */

-- 1. Revenue and profit by year and product category
SELECT
    YEAR(f.OrderDate)   AS OrderYear,
    p.CategoryName,
    SUM(f.Revenue)      AS TotalRevenue,
    SUM(f.Profit)       AS TotalProfit,
    ROUND(SUM(f.Profit) * 100.0 / NULLIF(SUM(f.Revenue), 0), 2) AS ProfitMarginPct
FROM dbo.fact_sales f
JOIN dbo.dim_product p ON f.ProductKey = p.ProductKey
GROUP BY YEAR(f.OrderDate), p.CategoryName
ORDER BY OrderYear, TotalRevenue DESC;

-- 2. Top 10 products by revenue
SELECT TOP 10
    p.ProductName,
    p.CategoryName,
    SUM(f.Revenue) AS TotalRevenue,
    SUM(f.OrderQuantity) AS UnitsSold
FROM dbo.fact_sales f
JOIN dbo.dim_product p ON f.ProductKey = p.ProductKey
GROUP BY p.ProductName, p.CategoryName
ORDER BY TotalRevenue DESC;

-- 3. Return rate by product category (return quantity / sold quantity)
SELECT
    p.CategoryName,
    SUM(s.OrderQuantity)                                  AS UnitsSold,
    SUM(COALESCE(r.ReturnQuantity, 0))                    AS UnitsReturned,
    ROUND(SUM(COALESCE(r.ReturnQuantity, 0)) * 100.0
        / NULLIF(SUM(s.OrderQuantity), 0), 2)             AS ReturnRatePct
FROM dbo.fact_sales s
JOIN dbo.dim_product p ON s.ProductKey = p.ProductKey
LEFT JOIN dbo.fact_returns r ON r.ProductKey = s.ProductKey
GROUP BY p.CategoryName
ORDER BY ReturnRatePct DESC;

-- 4. Sales performance by territory/region
SELECT
    t.Region,
    t.Country,
    SUM(f.Revenue)  AS TotalRevenue,
    COUNT(DISTINCT f.OrderNumber) AS OrderCount,
    SUM(f.Revenue) / NULLIF(COUNT(DISTINCT f.OrderNumber), 0) AS AvgOrderValue
FROM dbo.fact_sales f
JOIN dbo.dim_territory t ON f.TerritoryKey = t.TerritoryKey
GROUP BY t.Region, t.Country
ORDER BY TotalRevenue DESC;

-- 5. Customer segment value (from the RFM mart) — who to target for retention campaigns
SELECT
    Segment,
    COUNT(*)             AS CustomerCount,
    ROUND(AVG(Monetary), 2) AS AvgLifetimeSpend,
    ROUND(AVG(Recency), 1)  AS AvgDaysSinceLastOrder
FROM dbo.customer_rfm_segments
GROUP BY Segment
ORDER BY AvgLifetimeSpend DESC;

-- 6. Month-over-month revenue growth (window function — good interview talking point)
SELECT
    YearMonth,
    SUM(TotalRevenue) AS Revenue,
    LAG(SUM(TotalRevenue)) OVER (ORDER BY YearMonth) AS PrevMonthRevenue,
    ROUND(
        (SUM(TotalRevenue) - LAG(SUM(TotalRevenue)) OVER (ORDER BY YearMonth))
        * 100.0 / NULLIF(LAG(SUM(TotalRevenue)) OVER (ORDER BY YearMonth), 0), 2
    ) AS MoM_GrowthPct
FROM dbo.monthly_sales_summary
GROUP BY YearMonth
ORDER BY YearMonth;

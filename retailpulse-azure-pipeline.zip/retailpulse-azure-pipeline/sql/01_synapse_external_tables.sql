/* =========================================================================
   RetailPulse — Azure End-to-End Data Engineering Pipeline
   Synapse Serverless SQL Pool — External tables over the Gold Delta layer
   =========================================================================
   Run this in a Synapse "Serverless SQL pool" query window (or the built-in
   ondemand pool). Serverless is used instead of a Dedicated pool because we
   only need query-time compute for a portfolio-sized dataset — no reason to
   pay for a warehouse sitting idle. Swap CREATE EXTERNAL TABLE for
   CREATE TABLE (dedicated pool + COPY INTO) if you want to show you can
   also design for larger, latency-sensitive production workloads.
   ========================================================================= */

CREATE DATABASE SCOPED CREDENTIAL cred_adls
WITH IDENTITY = 'Managed Identity';
GO

CREATE EXTERNAL DATA SOURCE gold_source
WITH (
    LOCATION = 'abfss://gold@adventureworksdls.dfs.core.windows.net',
    CREDENTIAL = cred_adls
);
GO

CREATE EXTERNAL FILE FORMAT delta_format
WITH (FORMAT_TYPE = DELTA);
GO

-- ---------------------------------------------------------------------
-- Dimension tables
-- ---------------------------------------------------------------------

CREATE EXTERNAL TABLE dbo.dim_customer (
    CustomerKey     INT,
    FullName        VARCHAR(200),
    Gender          CHAR(1),
    MaritalStatus   CHAR(1),
    AnnualIncome    FLOAT,
    TotalChildren   INT,
    EducationLevel  VARCHAR(50),
    Occupation      VARCHAR(50),
    HomeOwner       CHAR(1),
    BirthDate       DATE
)
WITH (
    LOCATION = '/dim_customer',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

CREATE EXTERNAL TABLE dbo.dim_product (
    ProductKey       INT,
    ProductName      VARCHAR(200),
    ModelName        VARCHAR(100),
    ProductSKU       VARCHAR(50),
    ProductColor     VARCHAR(30),
    CategoryName     VARCHAR(50),
    SubcategoryName  VARCHAR(50),
    ProductCost      FLOAT,
    ProductPrice     FLOAT,
    MarginPct        FLOAT
)
WITH (
    LOCATION = '/dim_product',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

CREATE EXTERNAL TABLE dbo.dim_territory (
    TerritoryKey INT,
    Region       VARCHAR(50),
    Country      VARCHAR(50),
    Continent    VARCHAR(50)
)
WITH (
    LOCATION = '/dim_territory',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

CREATE EXTERNAL TABLE dbo.dim_calendar (
    [Date]       DATE,
    [Year]       INT,
    [Month]      INT,
    MonthName    VARCHAR(20),
    Quarter      INT,
    DayOfWeek    VARCHAR(20)
)
WITH (
    LOCATION = '/dim_calendar',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

-- ---------------------------------------------------------------------
-- Fact tables
-- ---------------------------------------------------------------------

CREATE EXTERNAL TABLE dbo.fact_sales (
    OrderNumber     VARCHAR(20),
    OrderLineItem   INT,
    OrderDate       DATE,
    StockDate       DATE,
    CustomerKey     INT,
    ProductKey      INT,
    TerritoryKey    INT,
    OrderQuantity   INT,
    Revenue         FLOAT,
    Cost            FLOAT,
    Profit          FLOAT
)
WITH (
    LOCATION = '/fact_sales',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

CREATE EXTERNAL TABLE dbo.fact_returns (
    ReturnDate      DATE,
    TerritoryKey    INT,
    ProductKey      INT,
    ReturnQuantity  INT
)
WITH (
    LOCATION = '/fact_returns',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

-- ---------------------------------------------------------------------
-- Pre-aggregated marts (already computed in the Gold notebook)
-- ---------------------------------------------------------------------

CREATE EXTERNAL TABLE dbo.monthly_sales_summary (
    YearMonth     VARCHAR(7),
    Region        VARCHAR(50),
    Country       VARCHAR(50),
    TotalRevenue  FLOAT,
    TotalProfit   FLOAT,
    UnitsSold     INT,
    OrderCount    INT
)
WITH (
    LOCATION = '/monthly_sales_summary',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

CREATE EXTERNAL TABLE dbo.customer_rfm_segments (
    CustomerKey  INT,
    Recency      INT,
    Frequency    INT,
    Monetary     FLOAT,
    R_Score      INT,
    F_Score      INT,
    M_Score      INT,
    RFM_Score    INT,
    Segment      VARCHAR(30),
    FullName     VARCHAR(200)
)
WITH (
    LOCATION = '/customer_rfm_segments',
    DATA_SOURCE = gold_source,
    FILE_FORMAT = delta_format
);
GO

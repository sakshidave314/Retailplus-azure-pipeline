# RetailPulse — Azure End-to-End Data Engineering Pipeline

![CI](https://github.com/YOUR_USERNAME/retailpulse-azure-pipeline/actions/workflows/validate.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.11-blue)
![Azure](https://img.shields.io/badge/Azure-Data%20Factory%20%7C%20Databricks%20%7C%20Synapse-0078D4)
![License](https://img.shields.io/badge/license-MIT-green)

**RetailPulse** is an end-to-end data engineering pipeline on Azure that turns raw
AdventureWorks retail sales data (2015–2017, ~56K transactions, 18K customers, 293
products) into a BI-ready analytics layer — built with a medallion (Bronze/Silver/Gold)
architecture, a star schema, and a customer RFM segmentation mart.

Infrastructure is defined as code (Bicep), pipeline logic is validated automatically on
every push (GitHub Actions), and secrets are never hardcoded (Azure Key Vault).


## Contents

- [Architecture](#architecture)
- [Results](#results)
- [Tech stack](#tech-stack)
- [Repo structure](#repo-structure)
- [Quickstart — validate locally in 2 minutes](#quickstart--validate-locally-in-2-minutes)
- [Full deployment to Azure](#full-deployment-to-azure)
- [Power BI](#power-bi)
- [Design decisions](#design-decisions--why-this-way)
- [What I'd improve next](#what-id-improve-next)
- [For recruiters / resume material](#for-recruiters--resume-material)

## Architecture

![Architecture diagram](architecture/architecture.svg)

```
Source CSVs
     |
     v
Azure Data Factory  ---------------------->  Azure Key Vault (secrets)
     |  (copy raw files, orchestrate)
     v
Azure Data Lake Storage Gen2
  ├── raw/      landed CSVs
  ├── bronze/   Delta tables — schema enforced, ingestion metadata      <- notebook 01
  ├── silver/   cleaned, deduped, type-cast, conformed                  <- notebook 02
  └── gold/     star schema + RFM mart + monthly sales summary          <- notebook 03
     |            (processed by Azure Databricks / PySpark / Delta Lake)
     v
Azure Synapse Analytics (Serverless SQL, external tables over Gold)
     |
     v
Power BI dashboard
     ^
     |
Azure DevOps / GitHub Actions — CI validates pipeline logic on every push
```

**Pointwise breakdown:**

1. **Source** — Raw AdventureWorks CSVs (customers, products, categories, sales 2015–2017, returns, territories, calendar).
2. **Ingestion** — Azure Data Factory copies raw files from a landing container into ADLS Gen2 `raw/` zone; orchestrates the whole pipeline end to end.
3. **Bronze layer** — Databricks/PySpark notebook reads raw files, enforces schema, adds ingestion metadata (`_ingested_at`, `_source_file`), writes as Delta tables. No business logic here — just a faithful raw copy.
4. **Silver layer** — Cleans and conforms Bronze data: fixes the ISO-8859-1 encoding issue, deduplicates, casts types, standardizes text, unions the 3 years of sales files, filters invalid rows (nulls, negative quantities).
5. **Gold layer** — Models Silver into a star schema (`fact_sales`, `dim_customer`, `dim_product`, `dim_territory`, `dim_calendar`, `fact_returns`) plus two business marts: `monthly_sales_summary` and `customer_rfm_segments` (Recency/Frequency/Monetary scoring → Champions/Loyal/At Risk/Lost).
6. **Serving layer** — Azure Synapse Serverless SQL creates external tables directly over the Gold Delta files — no data duplication, pay-per-query only.
7. **BI layer** — Power BI connects to Synapse; data model + DAX measures documented for revenue, profit margin, MoM growth, and segment breakdowns.
8. **Secrets management** — Azure Key Vault stores the storage account key and Databricks token; nothing hardcoded in ADF or notebooks.
9. **Infrastructure as Code** — Bicep template provisions all of the above (storage, ADF, Databricks, Synapse, Key Vault) with managed identities pre-wired, deployable via one script.
10. **CI/CD** — GitHub Actions validates the pipeline logic and Bicep syntax on every push; Azure DevOps documented as the path to deploy ADF/Databricks changes via pull request.

## Results

Pipeline logic has been run end-to-end against the real dataset in this repo
(`notebooks/local_validation_pandas.py` — see [Quickstart](#quickstart--validate-locally-in-2-minutes)):

| Metric | Value |
|---|---|
| Sales transactions processed | 56,046 |
| Customers | 18,148 (17,416 with completed orders) |
| Total revenue | $24,914,583.66 |
| Total profit | $10,457,736.53 |
| Customer segments (RFM) | Champions: 2,589 · Loyal: 4,859 · At Risk: 5,966 · Lost/Low-value: 4,002 |

## Tech stack

| Layer | Tool |
|---|---|
| Orchestration | Azure Data Factory |
| Storage | Azure Data Lake Storage Gen2 |
| Transformation | Azure Databricks (PySpark), Delta Lake |
| Serving | Azure Synapse Analytics (Serverless SQL) |
| BI | Power BI |
| Secrets | Azure Key Vault |
| Infrastructure as Code | Bicep |
| CI | GitHub Actions |

## Repo structure

```
notebooks/
  01_bronze_ingestion.py          Databricks notebook — raw CSV -> Bronze Delta
  02_silver_transformation.py     Databricks notebook — Bronze -> Silver (cleaning)
  03_gold_aggregation.py          Databricks notebook — Silver -> Gold (star schema + marts)
  local_validation_pandas.py      Local pandas equivalent — validates logic, no cluster needed
sql/
  01_synapse_external_tables.sql  External table DDL over the Gold Delta layer
  02_analytical_queries.sql       Business queries: revenue by category, RFM value, MoM growth
adf/
  pipelines/PL_AdventureWorks_Master.json   Master orchestration pipeline (importable JSON)
  linkedServices/LS_templates.json          Linked service templates (ADLS, Databricks, Key Vault)
  datasets/DS_templates.json                Dataset templates (source CSV, raw zone sink)
infra/
  bicep/main.bicep                One-command provisioning: storage, ADF, Databricks, Synapse, Key Vault
  deploy.sh                       Deployment script (az deployment group create)
architecture/
  architecture.svg                Architecture diagram (embedded above)
powerbi/
  POWERBI_SETUP.md                Data model relationships + copy-paste DAX measures
.github/workflows/
  validate.yml                    CI: runs the pipeline logic and validates Bicep on every push
data/
  bronze/                         Sample source CSVs (what ADF lands in raw/ -> bronze/)
  gold/                           Output of local_validation_pandas.py — proof the logic works
RESUME.md                         Resume bullets, LinkedIn write-up, interview talking points
```

**Pointwise breakdown:**

1. **`README.md`** — Main documentation: architecture, results, tech stack, quickstart, full deployment steps, design decisions.
2. **`RESUME.md`** — Resume bullets, LinkedIn write-up, interview talking points.
3. **`PUSH_TO_GITHUB.md`** — Instructions to push this pre-built repo to your own GitHub.
4. **`notebooks/`** — `01_bronze_ingestion.py`, `02_silver_transformation.py`, `03_gold_aggregation.py` (Databricks/PySpark), plus `local_validation_pandas.py` to prove the logic without a cluster.
5. **`sql/`** — `01_synapse_external_tables.sql` (DDL) and `02_analytical_queries.sql` (revenue, return rate, RFM value, MoM growth queries).
6. **`adf/`** — `pipelines/` (importable master pipeline JSON), `linkedServices/` and `datasets/` (connection templates).
7. **`infra/`** — `bicep/main.bicep` (IaC) and `deploy.sh` (one-command provisioning script).
8. **`architecture/`** — `architecture.svg`, the diagram embedded in the README.
9. **`powerbi/`** — `POWERBI_SETUP.md` with data model relationships and DAX measures.
10. **`.github/workflows/validate.yml`** — CI pipeline that runs on every push.
11. **`data/bronze/`** and **`data/gold/`** — sample source CSVs and proof-of-run output.
12. **`LICENSE`**, **`.gitignore`**, **`requirements.txt`** — standard repo hygiene files.

## Quickstart — validate locally in 2 minutes

No Azure account needed to prove the transformation logic works:

```bash
git clone https://github.com/YOUR_USERNAME/retailpulse-azure-pipeline.git
cd retailpulse-azure-pipeline
pip install -r requirements.txt
python3 notebooks/local_validation_pandas.py
```

This mirrors the Bronze → Silver → Gold logic in pandas against the real CSVs in
`data/bronze/` and writes Gold-layer CSVs to `data/gold/` — the same numbers reported
in [Results](#results) above.

## Full deployment to Azure

1. **Prerequisites**: an Azure subscription, [Azure CLI](https://learn.microsoft.com/cli/azure/install-azure-cli) installed, `az login` run.
2. **Provision infrastructure**:
   ```bash
   cd infra
   ./deploy.sh
   ```
   This creates a resource group and deploys `bicep/main.bicep` — a storage account
   (ADLS Gen2 with `raw`/`bronze`/`silver`/`gold`/`landing` containers), Azure Data
   Factory, Azure Databricks workspace, Azure Synapse workspace, and Key Vault, with
   managed identities wired up so ADF and Synapse can read/write the lake without
   hardcoded credentials.
3. **Upload source data**: upload `data/bronze/*.csv` to the `landing` container.
4. **Azure Data Factory**: open ADF Studio → import linked services from
   `adf/linkedServices/LS_templates.json` (fill in your real resource names), datasets
   from `adf/datasets/DS_templates.json`, and the pipeline from
   `adf/pipelines/PL_AdventureWorks_Master.json`.
5. **Azure Databricks**: attach a small cluster, import the three notebooks from
   `notebooks/`, update the `storage_account` widget default to your deployed account name.
6. **Run it**: trigger `PL_AdventureWorks_Master` in ADF — it copies files, then runs
   Bronze → Silver → Gold notebooks in sequence with retry policy and a failure webhook.
7. **Azure Synapse**: open a Serverless SQL script, run
   `sql/01_synapse_external_tables.sql`, then explore with `sql/02_analytical_queries.sql`.
8. **Power BI**: see [powerbi/POWERBI_SETUP.md](powerbi/POWERBI_SETUP.md) for the data
   model and ready-to-paste DAX measures.

## Power BI

Data model relationships and DAX measures (Total Revenue, Profit Margin %, Revenue MoM
Growth %, RFM segment counts, etc.) for building a report on top of the Gold layer are
in [powerbi/POWERBI_SETUP.md](powerbi/POWERBI_SETUP.md).

## Design decisions — why this way

- **Medallion architecture (Bronze/Silver/Gold)** — separates raw data from business
  logic, so Silver/Gold can be reprocessed without re-pulling from source, and lets you
  isolate whether an issue is a source problem or a transform bug by checking which
  layer diverges.
- **Delta Lake over plain Parquet** — gives ACID transactions, schema enforcement, and
  time travel, which matters once more than one pipeline run writes to the same table.
- **Serverless Synapse SQL instead of Dedicated** — this dataset doesn't need standing
  compute; serverless only charges per query. `sql/01_synapse_external_tables.sql`
  documents how to swap to a Dedicated pool with `COPY INTO` if latency/volume required it.
- **RFM customer segmentation** — turns raw transactions into a business-usable output
  (who's a "Champion" vs "At Risk") instead of stopping at clean tables.
- **Infrastructure as code (Bicep) + CI (GitHub Actions)** — the environment and pipeline
  logic are both reproducible and reviewed through pull requests, not hand-clicked in the
  Azure portal.
- **Real encoding bug caught and fixed**: `AdventureWorks_Customers.csv` is ISO-8859-1
  encoded (contains an accented name, "ANDRÉS"), not UTF-8 — reading it as UTF-8 throws a
  `UnicodeDecodeError`. Handled explicitly in both the Databricks ingestion notebook and
  the local validation script.

## What I'd improve next

- Auto Loader / streaming ingestion instead of static file lists, for true incremental loads
- SCD Type 2 on `dim_customer` and `dim_product` to track historical changes
- Data quality checks (Great Expectations or Databricks-native) between layers
- Refactor notebook cells into testable Python functions/package, with unit tests in CI
- Move the Synapse SQL admin password in `infra/bicep/main.bicep` to a Key Vault
  reference instead of an inline parameter (flagged in the template comments)

## For recruiters / resume material

See [RESUME.md](RESUME.md) for ready-to-use resume bullets (short and long versions),
a LinkedIn project write-up, and interview talking points that go beyond "what I built"
into "why I built it this way."

## License

MIT — see [LICENSE](LICENSE).

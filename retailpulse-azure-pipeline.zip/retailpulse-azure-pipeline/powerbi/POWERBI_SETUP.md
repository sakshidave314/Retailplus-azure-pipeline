# Power BI dashboard setup

A `.pbix` binary can't be generated outside Power BI Desktop, so this is the
exact model + measures to build once you connect — copy-paste ready.

## 1. Connect to data

Power BI Desktop → Get Data → Azure → **Azure Synapse Analytics SQL** →
enter your Synapse serverless SQL endpoint (`<workspace>-ondemand.sql.azuresynapse.net`) →
DirectQuery or Import (Import is fine at this data volume) → select all tables
under `dbo` created by `sql/01_synapse_external_tables.sql`.

## 2. Data model relationships

Set these up in Model view (Power BI usually auto-detects most of them):

| From | To | Cardinality |
|---|---|---|
| `fact_sales[CustomerKey]` | `dim_customer[CustomerKey]` | Many-to-one |
| `fact_sales[ProductKey]` | `dim_product[ProductKey]` | Many-to-one |
| `fact_sales[TerritoryKey]` | `dim_territory[TerritoryKey]` | Many-to-one |
| `fact_sales[OrderDate]` | `dim_calendar[Date]` | Many-to-one |
| `fact_returns[ProductKey]` | `dim_product[ProductKey]` | Many-to-one |

Mark `dim_calendar` as a **Date table** (Table tools → Mark as date table → `Date` column).

## 3. Core DAX measures

```dax
Total Revenue = SUM(fact_sales[Revenue])

Total Profit = SUM(fact_sales[Profit])

Profit Margin % =
DIVIDE([Total Profit], [Total Revenue], 0)

Total Orders = DISTINCTCOUNT(fact_sales[OrderNumber])

Average Order Value = DIVIDE([Total Revenue], [Total Orders], 0)

Total Units Sold = SUM(fact_sales[OrderQuantity])

Units Returned = SUM(fact_returns[ReturnQuantity])

Return Rate % = DIVIDE([Units Returned], [Total Units Sold], 0)

Revenue MoM Growth % =
VAR CurrentRevenue = [Total Revenue]
VAR PriorRevenue =
    CALCULATE([Total Revenue], DATEADD(dim_calendar[Date], -1, MONTH))
RETURN
    DIVIDE(CurrentRevenue - PriorRevenue, PriorRevenue, 0)

Champions Customer Count =
CALCULATE(
    DISTINCTCOUNT(customer_rfm_segments[CustomerKey]),
    customer_rfm_segments[Segment] = "Champions"
)
```

## 4. Suggested report pages

1. **Executive summary** — cards for Total Revenue / Total Profit / Total Orders /
   Profit Margin %, a line chart of monthly revenue, a map of revenue by territory.
2. **Product performance** — bar chart of top 10 products by revenue, treemap by
   category, a table with `Return Rate %` per category (flag anything above the
   dataset average).
3. **Customer segmentation** — donut chart of `customer_rfm_segments[Segment]`
   distribution, scatter plot of Recency vs Monetary colored by Segment, table of
   top 20 "Champions" by lifetime spend for a retention-campaign talking point.
4. **Territory drill-down** — matrix of Region/Country x monthly revenue with
   conditional formatting, slicer on `dim_calendar[Year]`.

## 5. Screenshot for your resume/portfolio

Once built, export each page as an image (File → Export → Image) and drop them
into `resume-assets/` in this repo, then reference them at the top of the main
README under a "Dashboard preview" section — recruiters and interviewers engage
far more with a project that has a visible dashboard screenshot than one that's
all code.

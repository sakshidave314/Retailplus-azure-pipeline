// =============================================================================
// RetailPulse — Azure End-to-End Data Engineering Pipeline — Infrastructure as Code
// Provisions: ADLS Gen2 storage, Azure Data Factory, Azure Databricks,
// Azure Synapse (serverless), and Key Vault.
//
// Deploy with: az deployment group create -g <rg-name> -f main.bicep
// =============================================================================

@description('Short unique suffix appended to resource names (e.g. your initials + date)')
param uniqueSuffix string = uniqueString(resourceGroup().id)

@description('Azure region for all resources')
param location string = resourceGroup().location

@description('Object ID of the user/service principal to grant Key Vault + Storage access')
param principalId string

var storageAccountName = 'awdls${uniqueSuffix}'
var dataFactoryName = 'aw-adf-${uniqueSuffix}'
var databricksWorkspaceName = 'aw-dbx-${uniqueSuffix}'
var synapseWorkspaceName = 'aw-synapse-${uniqueSuffix}'
var keyVaultName = 'aw-kv-${uniqueSuffix}'

// ---------------------------------------------------------------------------
// Storage account (ADLS Gen2) with raw / bronze / silver / gold containers
// ---------------------------------------------------------------------------
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: storageAccountName
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    isHnsEnabled: true // hierarchical namespace = ADLS Gen2
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
  }

  resource blobService 'blobServices' = {
    name: 'default'
    resource rawContainer 'containers' = {
      name: 'raw'
    }
    resource bronzeContainer 'containers' = {
      name: 'bronze'
    }
    resource silverContainer 'containers' = {
      name: 'silver'
    }
    resource goldContainer 'containers' = {
      name: 'gold'
    }
    resource landingContainer 'containers' = {
      name: 'landing'
    }
  }
}

// ---------------------------------------------------------------------------
// Key Vault — stores storage key + Databricks PAT token as secrets
// ---------------------------------------------------------------------------
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    accessPolicies: []
  }
}

resource kvSecretsUserRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, principalId, 'KeyVaultSecretsUser')
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '4633458b-17de-408a-b874-0445c86b69e6') // Key Vault Secrets User
    principalId: principalId
  }
}

// ---------------------------------------------------------------------------
// Azure Data Factory
// ---------------------------------------------------------------------------
resource dataFactory 'Microsoft.DataFactory/factories@2018-06-01' = {
  name: dataFactoryName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
}

// Grant ADF's managed identity Storage Blob Data Contributor on the lake
resource adfStorageRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, dataFactory.id, 'StorageBlobDataContributor')
  scope: storageAccount
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'ba92f5b4-2d11-453d-a403-e96b0029c9fe') // Storage Blob Data Contributor
    principalId: dataFactory.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// ---------------------------------------------------------------------------
// Azure Databricks workspace (standard tier — sufficient for a portfolio build)
// ---------------------------------------------------------------------------
resource databricksWorkspace 'Microsoft.Databricks/workspaces@2024-05-01' = {
  name: databricksWorkspaceName
  location: location
  sku: { name: 'standard' }
  properties: {
    managedResourceGroupId: subscriptionResourceId('Microsoft.Resources/resourceGroups', '${databricksWorkspaceName}-managed-rg')
  }
}

// ---------------------------------------------------------------------------
// Azure Synapse workspace (serverless SQL only — no dedicated SQL pool
// is provisioned, keeping this at effectively zero idle cost)
// ---------------------------------------------------------------------------
resource synapseWorkspace 'Microsoft.Synapse/workspaces@2021-06-01' = {
  name: synapseWorkspaceName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    defaultDataLakeStorage: {
      accountUrl: 'https://${storageAccountName}.dfs.core.windows.net'
      filesystem: 'gold'
    }
    sqlAdministratorLogin: 'sqladminuser'
    sqlAdministratorLoginPassword: 'ChangeMe!${uniqueString(resourceGroup().id)}123' // rotate immediately after deploy; move to Key Vault reference for production use
  }
}

resource synapseStorageRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, synapseWorkspace.id, 'StorageBlobDataContributor')
  scope: storageAccount
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', 'ba92f5b4-2d11-453d-a403-e96b0029c9fe')
    principalId: synapseWorkspace.identity.principalId
    principalType: 'ServicePrincipal'
  }
}

// ---------------------------------------------------------------------------
// Outputs
// ---------------------------------------------------------------------------
output storageAccountName string = storageAccount.name
output dataFactoryName string = dataFactory.name
output databricksWorkspaceUrl string = 'https://${databricksWorkspace.properties.workspaceUrl}'
output synapseWorkspaceName string = synapseWorkspace.name
output keyVaultName string = keyVault.name

#!/usr/bin/env bash
# =============================================================================
# Deploys the AdventureWorks Azure Data Engineering project infrastructure.
# Prerequisites: Azure CLI installed and logged in (`az login`).
# =============================================================================
set -euo pipefail

RESOURCE_GROUP="${RESOURCE_GROUP:-rg-adventureworks-de}"
LOCATION="${LOCATION:-eastus}"

echo "Creating resource group '$RESOURCE_GROUP' in '$LOCATION' (skips if it already exists)..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none

PRINCIPAL_ID=$(az ad signed-in-user show --query id -o tsv)
echo "Deploying infrastructure for principal $PRINCIPAL_ID..."

az deployment group create \
  --resource-group "$RESOURCE_GROUP" \
  --template-file "$(dirname "$0")/bicep/main.bicep" \
  --parameters principalId="$PRINCIPAL_ID" \
  --output table

echo ""
echo "Deployment complete. Next steps:"
echo "  1. Upload data/bronze/*.csv to the 'landing' container in the new storage account."
echo "  2. Open Azure Data Factory Studio and import adf/pipelines/PL_AdventureWorks_Master.json"
echo "  3. Open the Databricks workspace and import notebooks/*.py"
echo "  4. Run sql/01_synapse_external_tables.sql in the Synapse serverless SQL pool"
echo "  5. Connect Power BI to the Synapse serverless SQL endpoint"
echo ""
echo "IMPORTANT: rotate the Synapse SQL admin password immediately (see main.bicep comment)."

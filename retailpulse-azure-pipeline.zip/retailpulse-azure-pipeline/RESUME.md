# Resume & LinkedIn material

Copy-paste ready. Swap `[Your Name]`, dates, and links before using.

## Resume bullet — full version (Experience or Projects section)

> Designed and built an end-to-end Azure data engineering pipeline (Data Factory,
> Databricks/PySpark, Delta Lake, Synapse Analytics, Power BI) processing 56K+
> retail transactions across 18K customers using a medallion (Bronze/Silver/Gold)
> architecture; modeled a star schema and built an RFM customer segmentation mart,
> reducing manual reporting effort and surfacing $24.9M in tracked revenue across
> 3 years of sales data. Provisioned infrastructure as code (Bicep) and automated
> validation via GitHub Actions CI.

## Resume bullet — short version (space-constrained)

> Built an end-to-end Azure data pipeline (ADF, Databricks, Synapse, Power BI)
> using medallion architecture and star-schema modeling on 56K+ retail transactions,
> including automated customer segmentation and IaC deployment (Bicep).

## Resume bullet — emphasizing data quality (if that's the angle you want)

> Built a production-style Azure ETL pipeline with automated data quality handling
> (encoding fixes, deduplication, null/type validation) across 6 source tables,
> orchestrated via Azure Data Factory with retry logic and failure alerting.

## LinkedIn project description

**Title:** RetailPulse — Azure End-to-End Data Engineering Pipeline

**Description:**

Built an end-to-end data pipeline on Azure to turn 3 years of raw retail sales
data into a BI-ready analytics layer.

The pipeline follows a medallion architecture: raw CSVs land in Azure Data Lake
Storage Gen2 via Azure Data Factory, get cleaned and conformed in a Silver layer
using PySpark on Databricks, and are modeled into a star schema in Gold —
including a customer RFM (Recency/Frequency/Monetary) segmentation mart that
turns transaction history into an actionable "who to target for retention"
output. Azure Synapse serverless SQL serves the Gold layer to Power BI for
reporting.

Infrastructure is defined as code (Bicep) and pipeline logic is validated on
every push via GitHub Actions.

Stack: Azure Data Factory · Azure Databricks · PySpark · Delta Lake · Azure
Synapse Analytics · Power BI · Azure Key Vault · Bicep · GitHub Actions

Repo: [link to your GitHub repo]

## Interview talking points (the "why", not just the "what")

- **Why medallion architecture?** Separates raw ingestion from business logic —
  you can fix a transformation bug and replay Silver→Gold without re-pulling
  from source, and can point to exactly which layer diverged when debugging.
- **Why Delta Lake over plain Parquet?** ACID transactions and schema
  enforcement matter the moment more than one job writes to the same table;
  time travel lets you audit "what did this table look like before yesterday's
  run."
- **Why Serverless Synapse instead of a Dedicated pool?** No reason to pay for
  idle warehouse compute at this data volume — but be ready to explain when
  you'd switch (sustained heavy concurrent query load, need for materialized
  views, predictable latency SLAs).
- **A real bug you can describe honestly:** `AdventureWorks_Customers.csv` is
  ISO-8859-1 encoded, not UTF-8 — reading it as UTF-8 throws a
  `UnicodeDecodeError` on an accented name ("ANDRÉS"). Found and fixed in both
  the Databricks notebook and the local validation script. Small, real,
  and a much better answer than a rehearsed one.
- **What you'd improve given more time:** Auto Loader / streaming ingestion
  instead of a static file list, SCD Type 2 on `dim_customer`/`dim_product`,
  data quality checks (Great Expectations or Databricks-native) between layers,
  and refactoring notebook cells into testable Python functions/package.

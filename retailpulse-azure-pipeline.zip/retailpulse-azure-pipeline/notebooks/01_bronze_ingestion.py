# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze Layer — Raw Ingestion
# MAGIC **RetailPulse — Azure End-to-End Data Engineering Pipeline**
# MAGIC
# MAGIC Reads raw CSVs landed by Azure Data Factory into ADLS Gen2 `raw/` zone,
# MAGIC and writes them as Delta tables into the `bronze/` zone with minimal transformation
# MAGIC (schema enforcement + ingestion metadata only — no business logic here).

# COMMAND ----------

dbutils.widgets.text("storage_account", "adventureworksdls", "Storage Account Name")
storage_account = dbutils.widgets.get("storage_account")

raw_path = f"abfss://raw@{storage_account}.dfs.core.windows.net"
bronze_path = f"abfss://bronze@{storage_account}.dfs.core.windows.net"

# COMMAND ----------

from pyspark.sql import functions as F

files_to_ingest = {
    "customers":              "AdventureWorks_Customers.csv",
    "products":                "AdventureWorks_Products.csv",
    "product_categories":      "AdventureWorks_Product_Categories.csv",
    "product_subcategories":   "AdventureWorks_Product_Subcategories.csv",
    "territories":             "AdventureWorks_Territories.csv",
    "calendar":                "AdventureWorks_Calendar.csv",
    "returns":                 "AdventureWorks_Returns.csv",
    "sales_2015":              "AdventureWorks_Sales_2015.csv",
    "sales_2016":              "AdventureWorks_Sales_2016.csv",
    "sales_2017":              "AdventureWorks_Sales_2017.csv",
}

# COMMAND ----------

for table_name, file_name in files_to_ingest.items():
    df = (
        spark.read
        .option("header", True)
        .option("inferSchema", True)
        .option("encoding", "ISO-8859-1")  # AdventureWorks_Customers.csv has accented names (e.g. "ANDRÉS")
        .csv(f"{raw_path}/{file_name}")
        .withColumn("_ingested_at", F.current_timestamp())
        .withColumn("_source_file", F.lit(file_name))
    )

    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(f"{bronze_path}/{table_name}")
    )
    print(f"Ingested {file_name} -> bronze/{table_name}  ({df.count()} rows)")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Notes
# MAGIC - In production this notebook is triggered by the ADF pipeline `PL_Bronze_Ingestion` right after the Copy Activity lands files in `raw/`.
# MAGIC - `storage_account` is passed in as a Base Parameter from the ADF "Notebook" activity so this notebook is fully reusable across dev/test/prod.
# MAGIC - Auto Loader (`cloudFiles`) can replace the static file list above for true incremental/streaming ingestion once new files land daily.

# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer — Data Cleaning & Standardization
# MAGIC **RetailPulse — Azure End-to-End Data Engineering Pipeline**
# MAGIC
# MAGIC Reads raw Bronze Delta tables from ADLS Gen2, applies cleaning/standardization rules,
# MAGIC and writes conformed Silver Delta tables.
# MAGIC
# MAGIC Source: `abfss://bronze@<storage_account>.dfs.core.windows.net/`
# MAGIC Target: `abfss://silver@<storage_account>.dfs.core.windows.net/`

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, DoubleType, DateType

storage_account = dbutils.widgets.get("storage_account") if "storage_account" in [w for w in []] else "adventureworksdls"  # replace via widget/param in ADF
bronze_path = f"abfss://bronze@{storage_account}.dfs.core.windows.net"
silver_path = f"abfss://silver@{storage_account}.dfs.core.windows.net"

# COMMAND ----------

# MAGIC %md ### 1. Customers — clean income, dedupe, standardize casing

# COMMAND ----------

df_customers = spark.read.format("delta").load(f"{bronze_path}/customers")

df_customers_silver = (
    df_customers
    .withColumn("AnnualIncome", F.regexp_replace(F.col("AnnualIncome"), "[$,]", "").cast(DoubleType()))
    .withColumn("BirthDate", F.to_date("BirthDate", "M/d/yyyy"))
    .withColumn("FirstName", F.initcap(F.trim("FirstName")))
    .withColumn("LastName", F.initcap(F.trim("LastName")))
    .withColumn("EmailAddress", F.lower(F.trim("EmailAddress")))
    .withColumn("FullName", F.concat_ws(" ", "FirstName", "LastName"))
    .dropDuplicates(["CustomerKey"])
    .filter(F.col("CustomerKey").isNotNull())
)

df_customers_silver.write.format("delta").mode("overwrite").save(f"{silver_path}/customers")

# COMMAND ----------

# MAGIC %md ### 2. Products — join category + subcategory, clean cost/price

# COMMAND ----------

df_products = spark.read.format("delta").load(f"{bronze_path}/products")
df_subcat = spark.read.format("delta").load(f"{bronze_path}/product_subcategories")
df_cat = spark.read.format("delta").load(f"{bronze_path}/product_categories")

df_products_silver = (
    df_products
    .withColumn("ProductCost", F.col("ProductCost").cast(DoubleType()))
    .withColumn("ProductPrice", F.col("ProductPrice").cast(DoubleType()))
    .join(df_subcat, "ProductSubcategoryKey", "left")
    .join(df_cat, "ProductCategoryKey", "left")
    .withColumn("MarginPct", F.round((F.col("ProductPrice") - F.col("ProductCost")) / F.col("ProductPrice"), 4))
    .dropDuplicates(["ProductKey"])
)

df_products_silver.write.format("delta").mode("overwrite").save(f"{silver_path}/products")

# COMMAND ----------

# MAGIC %md ### 3. Territories — passthrough with standardization

# COMMAND ----------

df_territories_silver = (
    spark.read.format("delta").load(f"{bronze_path}/territories")
    .withColumn("Country", F.trim("Country"))
    .dropDuplicates(["SalesTerritoryKey"])
)
df_territories_silver.write.format("delta").mode("overwrite").save(f"{silver_path}/territories")

# COMMAND ----------

# MAGIC %md ### 4. Calendar — parse dates, add fiscal attributes

# COMMAND ----------

df_calendar_silver = (
    spark.read.format("delta").load(f"{bronze_path}/calendar")
    .withColumn("Date", F.to_date("Date", "M/d/yyyy"))
    .withColumn("Year", F.year("Date"))
    .withColumn("Month", F.month("Date"))
    .withColumn("MonthName", F.date_format("Date", "MMMM"))
    .withColumn("Quarter", F.quarter("Date"))
    .withColumn("DayOfWeek", F.date_format("Date", "EEEE"))
)
df_calendar_silver.write.format("delta").mode("overwrite").save(f"{silver_path}/calendar")

# COMMAND ----------

# MAGIC %md ### 5. Sales — union 2015/2016/2017, cast types, filter invalid rows

# COMMAND ----------

df_sales_raw = (
    spark.read.format("delta").load(f"{bronze_path}/sales_2015")
    .unionByName(spark.read.format("delta").load(f"{bronze_path}/sales_2016"))
    .unionByName(spark.read.format("delta").load(f"{bronze_path}/sales_2017"))
)

df_sales_silver = (
    df_sales_raw
    .withColumn("OrderDate", F.to_date("OrderDate", "M/d/yyyy"))
    .withColumn("StockDate", F.to_date("StockDate", "M/d/yyyy"))
    .withColumn("OrderQuantity", F.col("OrderQuantity").cast(IntegerType()))
    .filter(F.col("OrderQuantity") > 0)
    .filter(F.col("CustomerKey").isNotNull() & F.col("ProductKey").isNotNull())
    .dropDuplicates(["OrderNumber", "OrderLineItem"])
)

df_sales_silver.write.format("delta").mode("overwrite").partitionBy("TerritoryKey").save(f"{silver_path}/sales")

# COMMAND ----------

# MAGIC %md ### 6. Returns — clean and standardize

# COMMAND ----------

df_returns_silver = (
    spark.read.format("delta").load(f"{bronze_path}/returns")
    .withColumn("ReturnDate", F.to_date("ReturnDate", "M/d/yyyy"))
    .withColumn("ReturnQuantity", F.col("ReturnQuantity").cast(IntegerType()))
    .filter(F.col("ReturnQuantity") > 0)
)
df_returns_silver.write.format("delta").mode("overwrite").save(f"{silver_path}/returns")

# COMMAND ----------

print("Silver layer complete: customers, products, territories, calendar, sales, returns")

# Databricks notebook source
# MAGIC %md
# MAGIC # Gold Layer — Star Schema for BI
# MAGIC **RetailPulse — Azure End-to-End Data Engineering Pipeline**
# MAGIC
# MAGIC Builds business-ready dimensional model (fact + dims) and pre-aggregated marts
# MAGIC from Silver tables. This is what Synapse Serverless SQL / Power BI reads from.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

storage_account = "adventureworksdls"
silver_path = f"abfss://silver@{storage_account}.dfs.core.windows.net"
gold_path = f"abfss://gold@{storage_account}.dfs.core.windows.net"

df_sales = spark.read.format("delta").load(f"{silver_path}/sales")
df_returns = spark.read.format("delta").load(f"{silver_path}/returns")
df_customers = spark.read.format("delta").load(f"{silver_path}/customers")
df_products = spark.read.format("delta").load(f"{silver_path}/products")
df_territories = spark.read.format("delta").load(f"{silver_path}/territories")
df_calendar = spark.read.format("delta").load(f"{silver_path}/calendar")

# COMMAND ----------

# MAGIC %md ### dim_customer

# COMMAND ----------

dim_customer = df_customers.select(
    "CustomerKey", "FullName", "Gender", "MaritalStatus", "AnnualIncome",
    "TotalChildren", "EducationLevel", "Occupation", "HomeOwner", "BirthDate"
)
dim_customer.write.format("delta").mode("overwrite").save(f"{gold_path}/dim_customer")

# COMMAND ----------

# MAGIC %md ### dim_product

# COMMAND ----------

dim_product = df_products.select(
    "ProductKey", "ProductName", "ModelName", "ProductSKU", "ProductColor",
    "CategoryName", "SubcategoryName", "ProductCost", "ProductPrice", "MarginPct"
)
dim_product.write.format("delta").mode("overwrite").save(f"{gold_path}/dim_product")

# COMMAND ----------

# MAGIC %md ### dim_territory / dim_calendar (light passthrough)

# COMMAND ----------

dim_territory = df_territories.withColumnRenamed("SalesTerritoryKey", "TerritoryKey")
dim_territory.write.format("delta").mode("overwrite").save(f"{gold_path}/dim_territory")
df_calendar.write.format("delta").mode("overwrite").save(f"{gold_path}/dim_calendar")

# COMMAND ----------

# MAGIC %md ### fact_sales — grain: one row per order line, with revenue calculated

# COMMAND ----------

fact_sales = (
    df_sales.alias("s")
    .join(df_products.select("ProductKey", "ProductPrice", "ProductCost"), "ProductKey", "left")
    .withColumn("Revenue", F.round(F.col("OrderQuantity") * F.col("ProductPrice"), 2))
    .withColumn("Cost", F.round(F.col("OrderQuantity") * F.col("ProductCost"), 2))
    .withColumn("Profit", F.round(F.col("Revenue") - F.col("Cost"), 2))
    .select(
        "OrderNumber", "OrderLineItem", "OrderDate", "StockDate",
        "CustomerKey", "ProductKey", "TerritoryKey",
        "OrderQuantity", "Revenue", "Cost", "Profit"
    )
)
fact_sales.write.format("delta").mode("overwrite").partitionBy("TerritoryKey").save(f"{gold_path}/fact_sales")

# COMMAND ----------

# MAGIC %md ### fact_returns

# COMMAND ----------

df_returns.write.format("delta").mode("overwrite").save(f"{gold_path}/fact_returns")

# COMMAND ----------

# MAGIC %md ### mart: monthly_sales_summary — pre-aggregated for fast Power BI queries

# COMMAND ----------

monthly_sales_summary = (
    fact_sales
    .withColumn("YearMonth", F.date_format("OrderDate", "yyyy-MM"))
    .join(dim_territory, "TerritoryKey", "left")
    .groupBy("YearMonth", "Region", "Country")
    .agg(
        F.sum("Revenue").alias("TotalRevenue"),
        F.sum("Profit").alias("TotalProfit"),
        F.sum("OrderQuantity").alias("UnitsSold"),
        F.countDistinct("OrderNumber").alias("OrderCount"),
    )
    .orderBy("YearMonth")
)
monthly_sales_summary.write.format("delta").mode("overwrite").save(f"{gold_path}/monthly_sales_summary")

# COMMAND ----------

# MAGIC %md ### mart: customer_rfm_segments — Recency / Frequency / Monetary segmentation

# COMMAND ----------

snapshot_date = fact_sales.agg(F.max("OrderDate")).collect()[0][0]

rfm_base = (
    fact_sales
    .groupBy("CustomerKey")
    .agg(
        F.datediff(F.lit(snapshot_date), F.max("OrderDate")).alias("Recency"),
        F.countDistinct("OrderNumber").alias("Frequency"),
        F.sum("Revenue").alias("Monetary"),
    )
)

r_window = Window.orderBy(F.col("Recency").desc())
f_window = Window.orderBy(F.col("Frequency"))
m_window = Window.orderBy(F.col("Monetary"))

rfm_scored = (
    rfm_base
    .withColumn("R_Score", F.ntile(5).over(r_window))
    .withColumn("F_Score", F.ntile(5).over(f_window))
    .withColumn("M_Score", F.ntile(5).over(m_window))
    .withColumn("RFM_Score", F.col("R_Score") + F.col("F_Score") + F.col("M_Score"))
    .withColumn(
        "Segment",
        F.when(F.col("RFM_Score") >= 13, "Champions")
         .when(F.col("RFM_Score") >= 10, "Loyal Customers")
         .when(F.col("RFM_Score") >= 7, "At Risk")
         .otherwise("Lost / Low-Value")
    )
    .join(df_customers.select("CustomerKey", "FullName"), "CustomerKey", "left")
)

rfm_scored.write.format("delta").mode("overwrite").save(f"{gold_path}/customer_rfm_segments")

# COMMAND ----------

print("Gold layer complete: dim_customer, dim_product, dim_territory, dim_calendar, "
      "fact_sales, fact_returns, monthly_sales_summary, customer_rfm_segments")

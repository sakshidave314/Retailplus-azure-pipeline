"""
Local validation of the Bronze -> Silver -> Gold logic using pandas.

This is NOT part of the Azure deployment — it's a fast local sanity check
(no cluster needed) to prove the transformation logic in 01/02/03 notebooks
produces correct results before you lift-and-shift to Databricks/PySpark.

Run: python3 local_validation_pandas.py
"""
import pandas as pd
import numpy as np
import os

BRONZE = "data/bronze"
GOLD = "data/gold"
os.makedirs(GOLD, exist_ok=True)

# ---------- Bronze load ----------
customers = pd.read_csv(f"{BRONZE}/AdventureWorks_Customers.csv", encoding="latin1")
products = pd.read_csv(f"{BRONZE}/AdventureWorks_Products.csv")
subcats = pd.read_csv(f"{BRONZE}/AdventureWorks_Product_Subcategories.csv")
cats = pd.read_csv(f"{BRONZE}/AdventureWorks_Product_Categories.csv")
territories = pd.read_csv(f"{BRONZE}/AdventureWorks_Territories.csv")
calendar = pd.read_csv(f"{BRONZE}/AdventureWorks_Calendar.csv")
returns = pd.read_csv(f"{BRONZE}/AdventureWorks_Returns.csv")
sales = pd.concat([
    pd.read_csv(f"{BRONZE}/AdventureWorks_Sales_2015.csv"),
    pd.read_csv(f"{BRONZE}/AdventureWorks_Sales_2016.csv"),
    pd.read_csv(f"{BRONZE}/AdventureWorks_Sales_2017.csv"),
], ignore_index=True)

print(f"Bronze loaded: customers={len(customers)}, products={len(products)}, "
      f"sales={len(sales)}, returns={len(returns)}, territories={len(territories)}")

# ---------- Silver ----------
customers["AnnualIncome"] = (
    customers["AnnualIncome"].astype(str).str.replace(r"[$,]", "", regex=True).astype(float)
)
customers["FirstName"] = customers["FirstName"].str.title()
customers["LastName"] = customers["LastName"].str.title()
customers["FullName"] = customers["FirstName"] + " " + customers["LastName"]
customers = customers.drop_duplicates(subset="CustomerKey")

products = products.merge(subcats, on="ProductSubcategoryKey", how="left")
products = products.merge(cats, on="ProductCategoryKey", how="left")
products["MarginPct"] = ((products["ProductPrice"] - products["ProductCost"]) / products["ProductPrice"]).round(4)

sales["OrderDate"] = pd.to_datetime(sales["OrderDate"], format="%m/%d/%Y", errors="coerce")
sales = sales[sales["OrderQuantity"] > 0]
sales = sales.dropna(subset=["CustomerKey", "ProductKey"])
sales = sales.drop_duplicates(subset=["OrderNumber", "OrderLineItem"])

returns["ReturnDate"] = pd.to_datetime(returns["ReturnDate"], format="%m/%d/%Y", errors="coerce")
returns = returns[returns["ReturnQuantity"] > 0]

print(f"Silver: customers={len(customers)}, products={len(products)}, sales={len(sales)} (after cleaning)")

# ---------- Gold: fact_sales ----------
fact_sales = sales.merge(products[["ProductKey", "ProductPrice", "ProductCost"]], on="ProductKey", how="left")
fact_sales["Revenue"] = (fact_sales["OrderQuantity"] * fact_sales["ProductPrice"]).round(2)
fact_sales["Cost"] = (fact_sales["OrderQuantity"] * fact_sales["ProductCost"]).round(2)
fact_sales["Profit"] = (fact_sales["Revenue"] - fact_sales["Cost"]).round(2)

fact_sales.to_csv(f"{GOLD}/fact_sales.csv", index=False)
customers.to_csv(f"{GOLD}/dim_customer.csv", index=False)
products.to_csv(f"{GOLD}/dim_product.csv", index=False)
territories.to_csv(f"{GOLD}/dim_territory.csv", index=False)

# ---------- Gold: monthly_sales_summary ----------
fact_sales["YearMonth"] = fact_sales["OrderDate"].dt.strftime("%Y-%m")
fact_with_territory = fact_sales.merge(
    territories.rename(columns={"SalesTerritoryKey": "TerritoryKey"}), on="TerritoryKey", how="left"
)

monthly_summary = (
    fact_with_territory.groupby(["YearMonth", "Region", "Country"])
    .agg(
        TotalRevenue=("Revenue", "sum"),
        TotalProfit=("Profit", "sum"),
        UnitsSold=("OrderQuantity", "sum"),
        OrderCount=("OrderNumber", "nunique"),
    )
    .reset_index()
    .sort_values("YearMonth")
)
monthly_summary.to_csv(f"{GOLD}/monthly_sales_summary.csv", index=False)

# ---------- Gold: customer_rfm_segments ----------
snapshot_date = fact_sales["OrderDate"].max()
rfm = (
    fact_sales.groupby("CustomerKey")
    .agg(
        LastOrderDate=("OrderDate", "max"),
        Frequency=("OrderNumber", "nunique"),
        Monetary=("Revenue", "sum"),
    )
    .reset_index()
)
rfm["Recency"] = (snapshot_date - rfm["LastOrderDate"]).dt.days

rfm["R_Score"] = pd.qcut(rfm["Recency"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F_Score"] = pd.qcut(rfm["Frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M_Score"] = pd.qcut(rfm["Monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["RFM_Score"] = rfm["R_Score"] + rfm["F_Score"] + rfm["M_Score"]

def segment(score):
    if score >= 13:
        return "Champions"
    elif score >= 10:
        return "Loyal Customers"
    elif score >= 7:
        return "At Risk"
    return "Lost / Low-Value"

rfm["Segment"] = rfm["RFM_Score"].apply(segment)
rfm = rfm.merge(customers[["CustomerKey", "FullName"]], on="CustomerKey", how="left")
rfm.to_csv(f"{GOLD}/customer_rfm_segments.csv", index=False)

# ---------- Summary printout ----------
print("\n=== GOLD LAYER SUMMARY ===")
print(f"fact_sales: {len(fact_sales)} rows | Total Revenue: ${fact_sales['Revenue'].sum():,.2f}")
print(f"Total Profit: ${fact_sales['Profit'].sum():,.2f}")
print(f"\nmonthly_sales_summary: {len(monthly_summary)} rows")
print(monthly_summary.head())
print(f"\ncustomer_rfm_segments: {len(rfm)} customers")
print(rfm["Segment"].value_counts())
print("\nGold CSVs written to data/gold/")
